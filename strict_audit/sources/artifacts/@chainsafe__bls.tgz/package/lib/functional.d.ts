import { IBls, PublicKeyArg, SignatureArg, SignatureSet } from "./types.js";
/**
 * NOTE:
 *
 * This conditional block below is present in most functions and is Herumi specific to prevent
 * downstream issues in the WASM code. It is not necessary to validateBytes for blst-native
 * code. The check for blst-native is implemented in the native layer.  All other byte checks
 * for the herumi code paths are found in the herumi classes for performance reasons as they
 * are byte-wise, only are required for the WASM and will unnecessarily slow down the
 * blst-native side.
 */
export declare function functionalInterfaceFactory({ implementation, SecretKey, PublicKey, Signature, }: Pick<IBls, "implementation" | "SecretKey" | "PublicKey" | "Signature">): {
    sign: (secretKey: Uint8Array, message: Uint8Array) => Uint8Array;
    aggregateSignatures: (signatures: SignatureArg[]) => Uint8Array;
    aggregatePublicKeys: (publicKeys: PublicKeyArg[]) => Uint8Array;
    verify: (publicKey: PublicKeyArg, message: Uint8Array, signature: SignatureArg) => boolean;
    asyncVerify: (publicKey: PublicKeyArg, message: Uint8Array, signature: SignatureArg) => Promise<boolean>;
    verifyAggregate: (publicKeys: PublicKeyArg[], message: Uint8Array, signature: SignatureArg) => boolean;
    asyncVerifyAggregate: (publicKeys: PublicKeyArg[], message: Uint8Array, signature: SignatureArg) => Promise<boolean>;
    verifyMultiple: (publicKeys: PublicKeyArg[], messages: Uint8Array[], signature: SignatureArg) => boolean;
    asyncVerifyMultiple: (publicKeys: PublicKeyArg[], messages: Uint8Array[], signature: SignatureArg) => Promise<boolean>;
    verifyMultipleSignatures: (sets: SignatureSet[]) => boolean;
    asyncVerifyMultipleSignatures: (sets: SignatureSet[]) => Promise<boolean>;
    secretKeyToPublicKey: (secretKey: Uint8Array) => Uint8Array;
};
