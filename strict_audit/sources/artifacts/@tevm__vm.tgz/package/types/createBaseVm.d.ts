export function createBaseVm(opts: import("./VmOpts.js").VmOpts): import("./BaseVm.js").BaseVm;
//# sourceMappingURL=createBaseVm.d.ts.map