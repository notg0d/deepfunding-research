export function createVm(opts: import("./VmOpts.js").VmOpts): import("./Vm.js").Vm;
//# sourceMappingURL=createVm.d.ts.map