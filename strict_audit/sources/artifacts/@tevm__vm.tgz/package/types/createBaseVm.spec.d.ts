export {};
//# sourceMappingURL=createBaseVm.spec.d.ts.map