import type { BaseVm } from '../BaseVm.js';
import type { RunBlockOpts, RunBlockResult } from '../utils/index.js';
export type RunBlock = (opts: RunBlockOpts) => Promise<RunBlockResult>;
/**
 * @ignore
 */
export declare const runBlock: (vm: BaseVm) => RunBlock;
//# sourceMappingURL=runBlock.d.ts.map