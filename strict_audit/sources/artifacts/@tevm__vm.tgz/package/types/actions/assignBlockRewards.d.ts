import { Block } from '@tevm/block';
import type { BaseVm } from '../BaseVm.js';
/**
 * Calculates block rewards for miner and ommers and puts
 * the updated balances of their accounts to state.
 */
export declare const assignBlockRewards: (vm: BaseVm) => (block: Block) => Promise<void>;
//# sourceMappingURL=assignBlockRewards.d.ts.map