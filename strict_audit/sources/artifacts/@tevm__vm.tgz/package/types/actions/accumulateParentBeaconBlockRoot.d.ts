import type { BaseVm } from '../BaseVm.js';
export declare const accumulateParentBeaconBlockRoot: (vm: BaseVm) => (root: Uint8Array, timestamp: bigint) => Promise<void>;
//# sourceMappingURL=accumulateParentBeaconBlockRoot.d.ts.map