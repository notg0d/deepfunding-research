import type { Block } from '@tevm/block';
import type { BaseVm } from '../BaseVm.js';
/**
 * Internal helper function to create an annotated error message
 *
 * @param msg Base error message
 * @hidden
 */
export declare function errorMsg(msg: string, vm: BaseVm, block: Block): string;
//# sourceMappingURL=errorMsg.d.ts.map