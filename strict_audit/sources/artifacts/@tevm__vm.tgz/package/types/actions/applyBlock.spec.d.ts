export {};
//# sourceMappingURL=applyBlock.spec.d.ts.map