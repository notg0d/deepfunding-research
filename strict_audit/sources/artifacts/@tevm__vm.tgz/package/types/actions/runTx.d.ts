import type { BaseVm } from '../BaseVm.js';
import type { RunTxOpts, RunTxResult } from '../utils/index.js';
export type RunTx = (opts: RunTxOpts) => Promise<RunTxResult>;
/**
 * @ignore
 */
export declare const runTx: (vm: BaseVm) => RunTx;
//# sourceMappingURL=runTx.d.ts.map