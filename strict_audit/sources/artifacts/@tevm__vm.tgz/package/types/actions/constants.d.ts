export const KECCAK256_NULL: import("viem").ByteArray;
//# sourceMappingURL=constants.d.ts.map