import type { BaseVm } from '../BaseVm.js';
import type { BuildBlockOpts } from '../utils/index.js';
import { BlockBuilder } from './BlockBuilder.js';
export type BuildBlock = (opts: BuildBlockOpts) => Promise<BlockBuilder>;
export declare const buildBlock: (vm: BaseVm) => BuildBlock;
//# sourceMappingURL=buildBlock.d.ts.map