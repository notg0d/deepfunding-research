export function validateRunTx(vm: import("../BaseVm.js").BaseVm): (opts: import("../utils/RunTxOpts.js").RunTxOpts) => Promise<{
    block: Block;
    preserveJournal: boolean;
    tx: import("@tevm/tx").TypedTransaction;
    skipNonce?: boolean;
    skipBalance?: boolean;
    skipBlockGasLimitValidation?: boolean;
    skipHardForkValidation?: boolean;
    reportAccessList?: boolean;
    reportPreimages?: boolean;
    blockGasUsed?: bigint;
}>;
import { Block } from '@tevm/block';
//# sourceMappingURL=validateRunTx.d.ts.map