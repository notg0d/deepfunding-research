export declare const parentBeaconBlockRootAddress: import("@tevm/utils").EthjsAddress;
//# sourceMappingURL=parentBeaconBlockRootAddress.d.ts.map