export declare function calculateMinerReward(minerReward: bigint, ommersNum: number): bigint;
//# sourceMappingURL=calculateMinerReward.d.ts.map