import { Block } from '@tevm/block';
/**
 * Generate the transaction trie for a block.
 * This is an intermediate step for computing the block header's
 * transaction root.
 * @param block - The block to generate the transaction trie for
 * @returns The transaction trie root
 */
export declare function genTxTrie(block: Block): Promise<Uint8Array<ArrayBufferLike>>;
//# sourceMappingURL=genTxTrie.d.ts.map