import type { Evm } from '@tevm/evm';
import { EthjsAccount, EthjsAddress } from '@tevm/utils';
export declare function rewardAccount(evm: Evm, address: EthjsAddress, reward: bigint): Promise<EthjsAccount>;
//# sourceMappingURL=rewardAccount.d.ts.map