import { Block } from '@tevm/block';
import type { BaseVm } from '../BaseVm.js';
export declare const assignWithdrawals: (vm: BaseVm) => (block: Block) => Promise<void>;
//# sourceMappingURL=assignWithdrawals.d.ts.map