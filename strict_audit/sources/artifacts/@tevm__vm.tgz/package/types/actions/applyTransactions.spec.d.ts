export {};
//# sourceMappingURL=applyTransactions.spec.d.ts.map