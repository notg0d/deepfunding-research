export declare function calculateOmmerReward(ommerBlockNumber: bigint, blockNumber: bigint, minerReward: bigint): bigint;
//# sourceMappingURL=calculateOmmerReward.d.ts.map