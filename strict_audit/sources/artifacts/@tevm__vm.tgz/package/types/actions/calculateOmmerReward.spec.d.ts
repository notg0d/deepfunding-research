export {};
//# sourceMappingURL=calculateOmmerReward.spec.d.ts.map