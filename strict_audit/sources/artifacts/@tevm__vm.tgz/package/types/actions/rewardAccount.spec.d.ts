export {};
//# sourceMappingURL=rewardAccount.spec.d.ts.map