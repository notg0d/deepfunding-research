import { Block } from '@tevm/block';
import type { BaseVm } from '../BaseVm.js';
import type { ApplyBlockResult, RunBlockOpts } from '../utils/index.js';
/**
 * Validates and applies a block, computing the results of
 * applying its transactions. This method doesn't modify the
 * block itself. It computes the block rewards and puts
 * them on state (but doesn't persist the changes).
 * @param {Block} block
 * @param {RunBlockOpts} opts
 */
export declare const applyBlock: (vm: BaseVm) => (block: Block, opts: RunBlockOpts) => Promise<ApplyBlockResult>;
//# sourceMappingURL=applyBlock.d.ts.map