export {};
//# sourceMappingURL=errorMsg.spec.d.ts.map