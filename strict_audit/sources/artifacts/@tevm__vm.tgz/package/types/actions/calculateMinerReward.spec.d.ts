export {};
//# sourceMappingURL=calculateMinerReward.spec.d.ts.map