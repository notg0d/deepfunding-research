/**
 * @internal
 * Creates a bloom filter from the logs.
 * @param {any[] | undefined} logs - The logs to create the bloom filter from.
 * @param {import('@tevm/common').Common} common - The common object.')}
 * @returns {Bloom}
 * @throws {never}
 */
export function txLogsBloom(logs: any[] | undefined, common: import("@tevm/common").Common): Bloom;
import { Bloom } from '@ethereumjs/vm';
//# sourceMappingURL=txLogsBloom.d.ts.map