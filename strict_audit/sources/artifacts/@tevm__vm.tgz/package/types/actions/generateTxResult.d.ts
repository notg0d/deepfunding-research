import type { TypedTransaction } from '@tevm/tx';
import type { BaseVm } from '../BaseVm.js';
import type { RunTxResult, TxReceipt } from '../utils/index.js';
/**
 * Returns the tx receipt.
 * @param this The vm instance
 * @param tx The transaction
 * @param txResult The tx result
 * @param cumulativeGasUsed The gas used in the block including this tx
 * @param blobGasUsed The blob gas used in the tx
 * @param blobGasPrice The blob gas price for the block including this tx
 */
export declare const generateTxReceipt: (vm: BaseVm) => (tx: TypedTransaction, txResult: RunTxResult, cumulativeGasUsed: bigint, blobGasUsed?: bigint, blobGasPrice?: bigint) => Promise<TxReceipt>;
//# sourceMappingURL=generateTxResult.d.ts.map