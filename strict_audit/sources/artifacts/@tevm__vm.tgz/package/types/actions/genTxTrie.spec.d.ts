export {};
//# sourceMappingURL=genTxTrie.spec.d.ts.map