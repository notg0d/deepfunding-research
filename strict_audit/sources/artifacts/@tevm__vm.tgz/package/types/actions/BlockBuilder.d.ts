import { Block } from '@tevm/block';
import { BlockGasLimitExceededError, EipNotEnabledError, InvalidGasLimitError } from '@tevm/errors';
import type { ImpersonatedTx, TypedTransaction } from '@tevm/tx';
import type { BaseVm } from '../BaseVm.js';
import type { BuildBlockOpts, RunTxOpts, RunTxResult, SealBlockOpts } from '../utils/index.js';
import type { BlockStatus } from './BlockStatus.js';
export type AddTransactionError = InvalidGasLimitError | EipNotEnabledError | BlockGasLimitExceededError;
export declare class BlockBuilder {
    /**
     * The cumulative gas used by the transactions added to the block.
     */
    gasUsed: bigint;
    /**
     *  The cumulative blob gas used by the blobs in a block
     */
    blobGasUsed: bigint;
    /**
     * Value of the block, represented by the final transaction fees
     * acruing to the miner.
     */
    private _minerValue;
    private readonly vm;
    private blockOpts;
    private headerData;
    private transactions;
    private transactionResults;
    private withdrawals?;
    private checkpointed;
    private blockStatus;
    get transactionReceipts(): import("../utils/TxReceipt.js").TxReceipt[];
    get minerValue(): bigint;
    constructor(vm: BaseVm, opts: BuildBlockOpts);
    /**
     * Throws if the block has already been built or reverted.
     */
    private checkStatus;
    getStatus(): BlockStatus;
    /**
     * Calculates and returns the transactionsTrie for the block.
     */
    transactionsTrie(): Promise<Uint8Array<ArrayBufferLike>>;
    /**
     * Calculates and returns the logs bloom for the block.
     */
    logsBloom(): Uint8Array<ArrayBufferLike>;
    /**
     * Calculates and returns the receiptTrie for the block.
     */
    receiptTrie(): Promise<Uint8Array<ArrayBufferLike>>;
    /**
     * Adds the block miner reward to the coinbase account.
     */
    private rewardMiner;
    /**
     * Adds the withdrawal amount to the withdrawal address
     */
    private processWithdrawals;
    /**
     * Run and add a transaction to the block being built.
     * Please note that this modifies the state of the VM.
     * Throws if the transaction's gasLimit is greater than
     * the remaining gas in the block.
     */
    addTransaction(tx: TypedTransaction | ImpersonatedTx, { skipBalance, skipNonce, skipHardForkValidation, }?: Pick<RunTxOpts, 'skipBalance' | 'skipNonce' | 'skipHardForkValidation'>): Promise<RunTxResult>;
    /**
     * Reverts the checkpoint on the StateManager to reset the state from any transactions that have been run.
     */
    revert(): Promise<void>;
    /**
     * This method returns the finalized block.
     * It also:
     *  - Assigns the reward for miner (PoW)
     *  - Commits the checkpoint on the StateManager
     *  - Sets the tip of the VM's blockchain to this block
     * For PoW, optionally seals the block with params `nonce` and `mixHash`,
     * which is validated along with the block number and difficulty by ethash.
     * For PoA, please pass `blockOption.cliqueSigner` into the buildBlock constructor,
     * as the signer will be awarded the txs amount spent on gas as they are added.
     */
    build(sealOpts?: SealBlockOpts): Promise<Block>;
    initState(): Promise<void>;
}
//# sourceMappingURL=BlockBuilder.d.ts.map