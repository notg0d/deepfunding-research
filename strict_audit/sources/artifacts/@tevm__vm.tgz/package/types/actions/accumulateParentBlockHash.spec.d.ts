export {};
//# sourceMappingURL=accumulateParentBlockHash.spec.d.ts.map