export function deepCopy(baseVm: import("../BaseVm.js").BaseVm): DeepCopy;
export type DeepCopyError = MisconfiguredClientError;
export type DeepCopy = () => Promise<import("../BaseVm.js").BaseVm>;
import { MisconfiguredClientError } from '@tevm/errors';
//# sourceMappingURL=deepCopy.d.ts.map