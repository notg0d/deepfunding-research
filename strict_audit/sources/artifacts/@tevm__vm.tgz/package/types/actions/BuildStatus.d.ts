export declare enum BuildStatus {
    Reverted = "reverted",
    Build = "build",
    Pending = "pending"
}
//# sourceMappingURL=BuildStatus.d.ts.map