export {};
//# sourceMappingURL=assignBlockRewards.spec.d.ts.map