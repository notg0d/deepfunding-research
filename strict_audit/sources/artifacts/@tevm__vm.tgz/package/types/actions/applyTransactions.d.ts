import { Bloom } from '@ethereumjs/vm';
import { Block } from '@tevm/block';
import type { BaseVm } from '../BaseVm.js';
import type { RunBlockOpts, RunTxResult, TxReceipt } from '../utils/index.js';
/**
 * Applies the transactions in a block, computing the receipts
 * as well as gas usage and some relevant data. This method is
 * side-effect free (it doesn't modify the block nor the state).
 */
export declare const applyTransactions: (vm: BaseVm) => (block: Block, opts: RunBlockOpts) => Promise<{
    bloom: Bloom;
    gasUsed: bigint;
    preimages: Map<string, Uint8Array<ArrayBufferLike>>;
    receiptsRoot: Uint8Array<ArrayBufferLike>;
    receipts: TxReceipt[];
    results: RunTxResult[];
}>;
//# sourceMappingURL=applyTransactions.d.ts.map