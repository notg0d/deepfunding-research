import type { Evm } from '@tevm/evm';
/**
 * Apply the DAO fork changes to the VM
 */
export declare function applyDAOHardfork(evm: Evm): Promise<void>;
//# sourceMappingURL=applyDAOHardfork.d.ts.map