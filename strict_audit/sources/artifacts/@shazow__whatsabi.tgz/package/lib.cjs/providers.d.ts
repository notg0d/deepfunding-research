import * as errors from "./errors.js";
export interface StorageProvider {
    getStorageAt(address: string, slot: number | string, block?: BlockTagOrNumber): Promise<string>;
}
export interface CallProvider {
    call(transaction: {
        to: string;
        data: string;
    }, block?: BlockTagOrNumber): Promise<string>;
}
export interface CodeProvider {
    getCode(address: string, block?: BlockTagOrNumber): Promise<string>;
}
export interface ENSProvider {
    getAddress(name: string): Promise<string>;
}
export interface Provider extends StorageProvider, CallProvider, CodeProvider, ENSProvider {
}
export interface AnyProvider {
}
export type BlockTagOrNumber = 'latest' | 'earliest' | 'pending' | 'safe' | 'finalized' | number | bigint;
export declare function CompatibleProvider(provider: any): Provider;
export declare function WithCachedCode(provider: AnyProvider, codeCache: Record<string, string>): Provider;
export declare function WithBlockNumber(provider: Provider, blockNumber: BlockTagOrNumber): Provider;
export declare class MissingENSProviderError extends errors.ProviderError {
}
export declare class Web3ProviderError extends errors.ProviderError {
}
