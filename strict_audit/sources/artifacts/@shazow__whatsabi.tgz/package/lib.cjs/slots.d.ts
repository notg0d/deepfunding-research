import type { StorageProvider } from "./providers.js";
export declare function joinSlot(parts: string[]): string;
export declare function addSlotOffset(slot: string, offset: number): string;
export declare function readArray(provider: StorageProvider, address: string, pos: number | string, width?: number, limit?: number): Promise<string[]>;
