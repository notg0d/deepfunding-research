"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fillEmptyNames = fillEmptyNames;
function fillEmptyNames(abi) {
    function processComponents(components) {
        components.forEach((component, index) => {
            component.name ||= `_param${index}`;
            if (isTupleType(component.type) && component.components) {
                processComponents(component.components);
            }
        });
    }
    const result = abi.map((item) => {
        if (item.type === "function") {
            const func = { ...item };
            func.inputs?.forEach((input) => {
                if (isTupleType(input.type) && input.components) {
                    processComponents(input.components);
                }
            });
            func.outputs?.forEach((output) => {
                if (isTupleType(output.type) && output.components) {
                    processComponents(output.components);
                }
            });
            return func;
        }
        return item;
    });
    return result;
}
function isTupleType(type) {
    return type.startsWith("tuple");
}
//# sourceMappingURL=abi.js.map