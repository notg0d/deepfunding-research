"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Program = exports.Function = exports.BytecodeIter = void 0;
exports.abiFromBytecode = abiFromBytecode;
exports.disasm = disasm;
const utils_js_1 = require("./utils.js");
const opcodes_js_1 = require("./opcodes.js");
const proxies_js_1 = require("./proxies.js");
function valueToOffset(value) {
    return parseInt((0, utils_js_1.bytesToHex)(value), 16);
}
class BytecodeIter {
    bytecode;
    nextStep;
    nextPos;
    posBuffer;
    posBufferSize;
    constructor(bytecode, config) {
        this.nextStep = 0;
        this.nextPos = 0;
        if (config === undefined)
            config = {};
        this.posBufferSize = Math.max(config.bufferSize || 1, 1);
        this.posBuffer = [];
        this.bytecode = (0, utils_js_1.hexToBytes)(bytecode);
    }
    hasMore() {
        return (this.bytecode.length > this.nextPos);
    }
    next() {
        if (this.bytecode.length <= this.nextPos)
            return opcodes_js_1.opcodes.STOP;
        const instruction = this.bytecode[this.nextPos];
        const width = (0, opcodes_js_1.pushWidth)(instruction);
        if (this.posBuffer.length >= this.posBufferSize)
            this.posBuffer.shift();
        this.posBuffer.push(this.nextPos);
        this.nextStep += 1;
        this.nextPos += 1 + width;
        return instruction;
    }
    step() {
        return this.nextStep - 1;
    }
    pos() {
        if (this.posBuffer.length === 0)
            return -1;
        return this.posBuffer[this.posBuffer.length - 1];
    }
    asPos(posOrRelativeStep) {
        let pos = posOrRelativeStep;
        if (pos < 0) {
            pos = this.posBuffer[this.posBuffer.length + pos];
            if (pos === undefined) {
                return -1;
            }
        }
        return pos;
    }
    at(posOrRelativeStep) {
        const pos = this.asPos(posOrRelativeStep);
        return this.bytecode[pos];
    }
    value() {
        return this.valueAt(-1);
    }
    valueAt(posOrRelativeStep) {
        const pos = this.asPos(posOrRelativeStep);
        const instruction = this.bytecode[pos];
        const width = (0, opcodes_js_1.pushWidth)(instruction);
        return this.bytecode.slice(pos + 1, pos + 1 + width);
    }
}
exports.BytecodeIter = BytecodeIter;
const interestingOpCodes = new Set([
    opcodes_js_1.opcodes.STOP,
    opcodes_js_1.opcodes.RETURN,
    opcodes_js_1.opcodes.CALLDATALOAD,
    opcodes_js_1.opcodes.CALLDATASIZE,
    opcodes_js_1.opcodes.CALLDATACOPY,
    opcodes_js_1.opcodes.DELEGATECALL,
    opcodes_js_1.opcodes.SLOAD,
    opcodes_js_1.opcodes.SSTORE,
    opcodes_js_1.opcodes.REVERT,
    opcodes_js_1.opcodes.CREATE,
    opcodes_js_1.opcodes.CREATE2,
]);
class Function {
    byteOffset;
    opTags;
    start;
    jumps;
    end;
    constructor(byteOffset = 0, start = 0) {
        this.byteOffset = byteOffset;
        this.start = start;
        this.opTags = new Set();
        this.jumps = [];
    }
}
exports.Function = Function;
class Program {
    dests;
    selectors;
    notPayable;
    fallback;
    eventCandidates;
    proxySlots;
    proxies;
    isFactory;
    sstoreCount;
    metadata;
    init;
    constructor(init) {
        this.dests = {};
        this.selectors = {};
        this.notPayable = {};
        this.eventCandidates = new Set();
        this.proxySlots = [];
        this.proxies = [];
        this.isFactory = false;
        this.sstoreCount = 0;
        this.init = init;
    }
}
exports.Program = Program;
function abiFromBytecode(bytecodeOrProgram) {
    const p = typeof bytecodeOrProgram === "string" ? disasm(bytecodeOrProgram) : bytecodeOrProgram;
    const abi = [];
    for (const [selector, offset] of Object.entries(p.selectors)) {
        if (!(offset in p.dests)) {
            continue;
        }
        const fn = p.dests[offset];
        const tags = subtreeTags(fn, p.dests);
        const funcABI = {
            type: "function",
            selector: selector,
            payable: !p.notPayable[offset],
        };
        let mutability = "nonpayable";
        if (funcABI.payable) {
            mutability = "payable";
        }
        else if (!tags.has(opcodes_js_1.opcodes.SSTORE)) {
            mutability = "view";
        }
        funcABI.stateMutability = mutability;
        if (tags.has(opcodes_js_1.opcodes.RETURN) || mutability === "view") {
            funcABI.outputs = [{ type: "bytes", name: "" }];
        }
        if (tags.has(opcodes_js_1.opcodes.CALLDATALOAD) || tags.has(opcodes_js_1.opcodes.CALLDATASIZE) || tags.has(opcodes_js_1.opcodes.CALLDATACOPY)) {
            funcABI.inputs = [{ type: "bytes", name: "" }];
        }
        abi.push(funcABI);
    }
    for (const h of p.eventCandidates) {
        abi.push({
            type: "event",
            hash: h,
        });
    }
    return abi;
}
const _EmptyArray = new Uint8Array();
function disasm(bytecode, config) {
    const { onlyJumpTable } = config || {};
    let p = new Program();
    const selectorDests = new Set();
    let invertedSelector = "";
    let lastPush32 = _EmptyArray;
    let checkJumpTable = true;
    let resumeJumpTable = new Set();
    let maxJumpDest = 0;
    let runtimeOffset = 0;
    let boundaryPos = -1;
    let currentFunction = new Function();
    p.dests[0] = currentFunction;
    const code = new BytecodeIter(bytecode, { bufferSize: 5 });
    while (code.hasMore()) {
        const inst = code.next();
        const pos = code.pos();
        const step = code.step();
        if (inst === opcodes_js_1.opcodes.PUSH32) {
            const v = code.value();
            const resolver = proxies_js_1.slotResolvers[(0, utils_js_1.bytesToHex)(v)];
            if (resolver !== undefined && !(p.proxies.length > 0 && p.proxies[0].name === resolver.name)) {
                p.proxies.push(resolver);
            }
            else {
                lastPush32 = v;
            }
            continue;
        }
        else if ((0, opcodes_js_1.isLog)(inst) && lastPush32.length > 0) {
            p.eventCandidates.add((0, utils_js_1.bytesToHex)(lastPush32));
            continue;
        }
        if (inst === opcodes_js_1.opcodes.DELEGATECALL &&
            code.at(-2) === opcodes_js_1.opcodes.GAS) {
            if ((0, opcodes_js_1.isPush)(code.at(-3))) {
                const val = code.valueAt(-3);
                const addr = (0, utils_js_1.bytesToHex)(val.slice(val.length - 20), 20);
                if (!p.proxies.find(p => p instanceof proxies_js_1.FixedProxyResolver && p.resolvedAddress === addr)) {
                    p.proxies.push(new proxies_js_1.FixedProxyResolver("HardcodedDelegateProxy", addr));
                }
            }
            else if (code.at(-3) === opcodes_js_1.opcodes.SLOAD &&
                code.at(-4) === opcodes_js_1.opcodes.ADDRESS) {
                p.proxies.push(new proxies_js_1.SequenceWalletProxyResolver());
            }
        }
        if (inst === opcodes_js_1.opcodes.JUMPDEST) {
            if ((0, opcodes_js_1.isHalt)(code.at(-2)) || code.at(-2) === opcodes_js_1.opcodes.JUMP) {
                if (currentFunction)
                    currentFunction.end = pos - 1 - runtimeOffset;
                currentFunction = new Function(step, pos);
                if (checkJumpTable && Object.keys(p.selectors).length > 0) {
                    checkJumpTable = false;
                }
                if (resumeJumpTable.delete(pos - runtimeOffset)) {
                    checkJumpTable = code.at(pos + 1) === opcodes_js_1.opcodes.DUP1 || code.at(pos + 1) === opcodes_js_1.opcodes.CALLDATALOAD;
                }
                else if (!checkJumpTable && resumeJumpTable.size === 0 && onlyJumpTable) {
                    break;
                }
            }
            p.dests[pos - runtimeOffset] = currentFunction;
            if (code.at(pos + 1) === opcodes_js_1.opcodes.CALLVALUE &&
                code.at(pos + 2) === opcodes_js_1.opcodes.DUP1 &&
                code.at(pos + 3) === opcodes_js_1.opcodes.ISZERO) {
                p.notPayable[pos - runtimeOffset] = step;
            }
            continue;
        }
        else if (((0, opcodes_js_1.isHalt)(code.at(-2)) || code.at(-2) === opcodes_js_1.opcodes.JUMP) &&
            runtimeOffset < pos &&
            maxJumpDest < pos) {
            boundaryPos = pos;
            break;
        }
        if (currentFunction.opTags !== undefined) {
            if ((inst === opcodes_js_1.opcodes.JUMP || inst === opcodes_js_1.opcodes.JUMPI) && (0, opcodes_js_1.isPush)(code.at(-2))) {
                const jumpOffset = valueToOffset(code.valueAt(-2));
                currentFunction.jumps.push(jumpOffset);
                maxJumpDest = Math.max(maxJumpDest, jumpOffset);
            }
            if (interestingOpCodes.has(inst)) {
                currentFunction.opTags.add(inst);
                if (inst === opcodes_js_1.opcodes.CREATE || inst === opcodes_js_1.opcodes.CREATE2) {
                    p.isFactory = true;
                }
                else if (inst === opcodes_js_1.opcodes.SSTORE) {
                    p.sstoreCount += 1;
                }
            }
        }
        if (code.at(-1) === opcodes_js_1.opcodes.CODECOPY &&
            (code.at(-2) === opcodes_js_1.opcodes.PUSH1 ||
                code.at(-2) === opcodes_js_1.opcodes.PUSH0 ||
                code.at(-2) === opcodes_js_1.opcodes.RETURNDATASIZE) &&
            (0, opcodes_js_1.isPush)(code.at(-3))) {
            const offsetDest = valueToOffset(code.valueAt(-3));
            resumeJumpTable.add(offsetDest);
            runtimeOffset = offsetDest;
            continue;
        }
        if (pos === runtimeOffset &&
            currentFunction.opTags.has(opcodes_js_1.opcodes.RETURN) &&
            !currentFunction.opTags.has(opcodes_js_1.opcodes.CALLDATALOAD)) {
            p = new Program(p);
            currentFunction = new Function();
            p.dests[0] = currentFunction;
            checkJumpTable = true;
        }
        if (!checkJumpTable)
            continue;
        if (inst === opcodes_js_1.opcodes.JUMP && (0, opcodes_js_1.isPush)(code.at(-2))) {
            const offsetDest = valueToOffset(code.valueAt(-2));
            if (invertedSelector !== "") {
                p.selectors[invertedSelector] = offsetDest;
                selectorDests.add(offsetDest);
                invertedSelector = "";
            }
            else {
                resumeJumpTable.add(offsetDest);
            }
        }
        if (!(code.at(-1) === opcodes_js_1.opcodes.JUMPI && (0, opcodes_js_1.isPush)(code.at(-2))))
            continue;
        const offsetDest = valueToOffset(code.valueAt(-2));
        currentFunction.jumps.push(offsetDest);
        if (code.at(-3) === opcodes_js_1.opcodes.EQ &&
            (0, opcodes_js_1.isPush)(code.at(-4))) {
            let value = code.valueAt(-4);
            const selector = (0, utils_js_1.bytesToHex)(value, 4);
            p.selectors[selector] = offsetDest;
            selectorDests.add(offsetDest);
            continue;
        }
        if (code.at(-3) === opcodes_js_1.opcodes.EQ &&
            code.at(-4) === opcodes_js_1.opcodes.DUP2 &&
            (0, opcodes_js_1.isPush)(code.at(-5))) {
            let value = code.valueAt(-5);
            const selector = (0, utils_js_1.bytesToHex)(value, 4);
            p.selectors[selector] = offsetDest;
            selectorDests.add(offsetDest);
            continue;
        }
        if (code.at(-3) === opcodes_js_1.opcodes.SUB &&
            (0, opcodes_js_1.isPush)(code.at(-4))) {
            invertedSelector = (0, utils_js_1.bytesToHex)(code.valueAt(-4), 4);
            p.fallback = offsetDest;
        }
        if (code.at(-3) === opcodes_js_1.opcodes.ISZERO &&
            code.at(-4) === opcodes_js_1.opcodes.DUP1 &&
            (code.at(-5) === opcodes_js_1.opcodes.CALLDATASIZE ||
                code.at(-5) === opcodes_js_1.opcodes.CALLDATALOAD ||
                code.at(-5) === opcodes_js_1.opcodes.JUMPDEST ||
                code.at(-5) === opcodes_js_1.opcodes.SHR)) {
            const selector = "0x00000000";
            p.selectors[selector] = offsetDest;
            selectorDests.add(offsetDest);
            continue;
        }
        if (code.at(-3) !== opcodes_js_1.opcodes.EQ &&
            (0, opcodes_js_1.isCompare)(code.at(-3)) &&
            code.at(-5) === opcodes_js_1.opcodes.DUP1) {
            resumeJumpTable.add(offsetDest);
            continue;
        }
    }
    let endBoundary = undefined;
    const finalByte = code.bytecode.slice(-1)[0];
    if (!(0, opcodes_js_1.isHalt)(finalByte) || code.bytecode.slice(-2)[0] === 0) {
        const cborLength = valueToOffset(code.bytecode.slice(-2));
        const metadataLength = cborLength + 2;
        const blobStart = code.bytecode.length - metadataLength;
        const looksLikeCBOR = blobStart >= boundaryPos && (code.bytecode[blobStart] & 0xe0) === 0xa0;
        if (looksLikeCBOR) {
            endBoundary = -metadataLength;
            const cborData = code.bytecode.slice(blobStart, -2);
            if (cborData.length === 51) {
                p.metadata = {
                    ipfs: (0, utils_js_1.bytesToHex)(cborData.slice(8, 42)),
                    solc: (0, utils_js_1.bytesToHex)(cborData.slice(48, 51)),
                };
            }
        }
    }
    if ((boundaryPos > 0 && p.proxies.length === 0)) {
        const auxData = (0, utils_js_1.bytesToHex)(code.bytecode.slice(boundaryPos, endBoundary));
        if (auxData.length >= 2 + 64) {
            for (const [slot, resolver] of Object.entries(proxies_js_1.slotResolvers)) {
                if (auxData.lastIndexOf(slot.slice(2)) === -1)
                    continue;
                p.proxies.push(resolver);
            }
            for (const [preimage, resolver] of Object.entries(proxies_js_1.slotPreimages)) {
                if (auxData.lastIndexOf(preimage.slice(2)) === -1)
                    continue;
                p.proxies.push(resolver);
            }
        }
    }
    if (p.proxies.length === 0) {
        const selectors = Object.keys(p.selectors);
        const hasDelegateCall = Object.values(p.dests).some((fn) => fn.opTags.has(opcodes_js_1.opcodes.DELEGATECALL));
        if (hasDelegateCall &&
            selectors.length === proxies_js_1.livepeerManagerProxySelectors.length &&
            proxies_js_1.livepeerManagerProxySelectors.every((s) => s in p.selectors)) {
            p.proxies.push(new proxies_js_1.LivepeerManagerProxyResolver());
        }
    }
    if (p.init && p.proxies.length === 0 && p.init.proxies.length > 0) {
        p.proxies = p.init.proxies;
    }
    if (!(proxies_js_1.aragonAppProxyImplementationSelector in p.selectors) &&
        p.proxies.some((r) => r instanceof proxies_js_1.AragonAppProxyResolver)) {
        p.proxies = p.proxies.filter((r) => !(r instanceof proxies_js_1.AragonAppProxyResolver));
    }
    return p;
}
function subtreeTags(entryFunc, dests) {
    let tags = new Set([]);
    const stack = new Array(entryFunc);
    const seen = new Set();
    while (stack.length > 0) {
        const fn = stack.pop();
        if (!fn)
            continue;
        if (seen.has(fn.start))
            continue;
        seen.add(fn.start);
        tags = new Set([...tags, ...fn.opTags]);
        stack.push(...fn.jumps.map(offset => dests[offset]));
    }
    return tags;
}
//# sourceMappingURL=disasm.js.map