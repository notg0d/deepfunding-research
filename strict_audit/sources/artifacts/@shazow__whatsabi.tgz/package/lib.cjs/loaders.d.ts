import * as errors from "./errors.js";
export type ContractResult = {
    abi: any[];
    name: string | null;
    ok: boolean;
    evmVersion?: string;
    compilerVersion?: string;
    runs?: number;
    getSources?: () => Promise<ContractSources>;
    loader?: ABILoader;
    loaderResult?: EtherscanContractResult | SourcifyContractMetadata | SourcifyContractResult | any;
};
export type ContractSources = Array<{
    path?: string;
    content: string;
}>;
export interface ABILoader {
    readonly name: string;
    loadABI(address: string): Promise<any[]>;
    getContract(address: string): Promise<ContractResult>;
}
export declare class MultiABILoader implements ABILoader {
    readonly name: string;
    loaders: ABILoader[];
    onLoad?: (loader: ABILoader) => void;
    constructor(loaders: ABILoader[]);
    getContract(address: string): Promise<ContractResult>;
    loadABI(address: string): Promise<any[]>;
}
export declare class MultiABILoaderError extends errors.LoaderError {
}
export declare class EtherscanABILoaderError extends errors.LoaderError {
}
export type EtherscanContractResult = {
    SourceCode: string;
    ABI: string;
    ContractName: string;
    CompilerVersion: string;
    OptimizationUsed: number;
    Runs: number;
    ConstructorArguments: string;
    EVMVersion: string;
    Library: string;
    LicenseType: string;
    Proxy: "1" | "0";
    Implementation: string;
    SwarmSource: string;
};
export declare class EtherscanV2ABILoader implements ABILoader {
    #private;
    readonly name: string;
    apiKey?: string;
    baseURL: string;
    constructor(config: {
        apiKey: string;
        chainId?: number;
    });
    getContract(address: string): Promise<ContractResult>;
    loadABI(address: string): Promise<any[]>;
}
export declare class EtherscanABILoader extends EtherscanV2ABILoader {
}
export declare class EtherscanV1ABILoader extends EtherscanV2ABILoader {
    readonly name: string;
    constructor(config?: {
        apiKey?: string;
        baseURL?: string;
    });
}
export declare class SourcifyABILoader implements ABILoader {
    #private;
    readonly name = "SourcifyABILoader";
    chainId?: number;
    constructor(config?: {
        chainId?: number;
    });
    static stripPathPrefix(path: string): string;
    getContract(address: string): Promise<ContractResult>;
    loadABI(address: string): Promise<any[]>;
}
export declare class SourcifyABILoaderError extends errors.LoaderError {
}
export interface SourcifyContractMetadata {
    compiler: {
        version: string;
    };
    language: string;
    output: {
        abi: any[];
        devdoc?: any;
        userdoc?: any;
    };
    settings: {
        compilationTarget: Record<string, string>;
        evmVersion: string;
        libraries: Record<string, string>;
        metadata: Record<string, string>;
        optimizer: any;
        remappings: string[];
    };
    sources: Record<string, any>;
    version: number;
}
export interface SourcifyContractResult {
    abi: any[];
    compilation?: {
        compilerVersion?: string;
        compilerSettings?: {
            evmVersion?: string;
            optimizer?: {
                runs?: number;
            };
        };
        name?: string;
        fullyQualifiedName?: string;
    };
    metadata?: SourcifyContractMetadata;
    sources?: Record<string, {
        content: string;
    }>;
    match?: "match" | "exact_match" | string;
}
export declare class BlockscoutABILoader implements ABILoader {
    #private;
    readonly name = "BlockscoutABILoader";
    apiKey?: string;
    baseURL: string;
    constructor(config?: {
        apiKey?: string;
        baseURL?: string;
        chainId?: number;
    });
    getContract(address: string): Promise<ContractResult>;
    loadABI(address: string): Promise<any[]>;
}
export declare class BlockscoutABILoaderError extends errors.LoaderError {
}
export type BlockscoutContractResult = {
    name?: string;
    language?: string;
    license_type?: string;
    is_verified?: boolean;
    is_fully_verified?: boolean;
    is_partially_verified?: boolean;
    is_verified_via_sourcify?: boolean;
    is_verified_via_eth_bytecode_db?: boolean;
    verified_twin_address_hash?: string;
    certified?: boolean;
    source_code?: string;
    source_code_html?: string;
    file_path?: string;
    file_path_html?: string;
    additional_sources?: Array<{
        file_path: string;
        source_code: string;
    }>;
    sourcify_repo_url?: string | null;
    creation_bytecode?: string;
    deployed_bytecode?: string;
    is_changed_bytecode?: boolean;
    is_self_destructed?: boolean;
    abi?: any[];
    has_methods_read?: boolean;
    has_methods_write?: boolean;
    has_custom_methods_read?: boolean;
    has_custom_methods_write?: boolean;
    can_be_visualized_via_sol2uml?: boolean;
    constructor_args?: string;
    decoded_constructor_args?: any[];
    compiler_version?: string;
    compiler_settings?: any;
    evm_version?: string;
    optimization_enabled?: boolean;
    optimization_runs?: number | null;
    is_blueprint?: boolean;
    is_vyper_contract?: boolean;
    proxy_type?: string;
    implementations?: Array<{
        address?: string;
        name?: string;
    }>;
    has_methods_read_proxy?: boolean;
    has_methods_write_proxy?: boolean;
};
export declare class AnyABILoader implements ABILoader {
    #private;
    readonly name = "AnyABILoader";
    chainId?: number;
    constructor(config?: {
        chainId?: number;
    });
    getContract(address: string): Promise<ContractResult>;
    loadABI(address: string): Promise<any[]>;
}
export declare class AnyABILoaderError extends errors.LoaderError {
}
export interface SignatureLookup {
    loadFunctions(selector: string): Promise<string[]>;
    loadEvents(hash: string): Promise<string[]>;
}
export declare class MultiSignatureLookup implements SignatureLookup {
    lookups: SignatureLookup[];
    constructor(lookups: SignatureLookup[]);
    loadFunctions(selector: string): Promise<string[]>;
    loadEvents(hash: string): Promise<string[]>;
}
export declare class FourByteSignatureLookup implements SignatureLookup {
    load(url: string): Promise<string[]>;
    loadFunctions(selector: string): Promise<string[]>;
    loadEvents(hash: string): Promise<string[]>;
}
export declare class FourByteSignatureLookupError extends errors.LoaderError {
}
export declare class OpenChainSignatureLookup implements SignatureLookup {
    load(url: string): Promise<any>;
    loadFunctions(selector: string): Promise<string[]>;
    loadEvents(hash: string): Promise<string[]>;
}
export declare class OpenChainSignatureLookupError extends errors.LoaderError {
}
export declare class SamczunSignatureLookup extends OpenChainSignatureLookup {
}
export declare const defaultABILoader: ABILoader;
export declare const defaultSignatureLookup: SignatureLookup;
type LoaderEnv = {
    CHAIN_ID?: string | number;
    SOURCIFY_CHAIN_ID?: string | number;
    ETHERSCAN_API_KEY: string;
    ETHERSCAN_CHAIN_ID?: string | number;
};
export declare function defaultsWithEnv(env: LoaderEnv): Record<string, ABILoader | SignatureLookup>;
export {};
