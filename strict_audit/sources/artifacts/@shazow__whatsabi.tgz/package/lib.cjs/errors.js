"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StorageReadError = exports.ProviderError = exports.LoaderError = exports.AutoloadError = exports.WhatsABIError = void 0;
class WhatsABIError extends Error {
    name = 'WhatsABIError';
    context;
    constructor(message, args = {}) {
        super(message, { cause: args.cause });
        this.context = args.context;
    }
}
exports.WhatsABIError = WhatsABIError;
class AutoloadError extends WhatsABIError {
    name = 'AutoloadError';
}
exports.AutoloadError = AutoloadError;
class LoaderError extends WhatsABIError {
    name = 'LoaderError';
}
exports.LoaderError = LoaderError;
class ProviderError extends WhatsABIError {
    name = 'ProviderError';
}
exports.ProviderError = ProviderError;
class StorageReadError extends WhatsABIError {
    name = 'StorageReadError';
}
exports.StorageReadError = StorageReadError;
//# sourceMappingURL=errors.js.map