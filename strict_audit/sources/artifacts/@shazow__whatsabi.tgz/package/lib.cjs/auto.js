"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultConfig = void 0;
exports.autoload = autoload;
const AbiFunction = __importStar(require("ox/AbiFunction"));
const AbiEvent = __importStar(require("ox/AbiEvent"));
const proxies_js_1 = require("./proxies.js");
const errors = __importStar(require("./errors.js"));
const providers_js_1 = require("./providers.js");
const loaders_js_1 = require("./loaders.js");
const disasm_js_1 = require("./disasm.js");
const loaders_js_2 = require("./loaders.js");
const PROXY_SSTORE_COUNT_MAX = 4;
const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000";
function isAddress(address) {
    return address.length === 42 && address.startsWith("0x") && Number(address) >= 0;
}
exports.defaultConfig = {
    onProgress: (_) => { },
    onError: (phase, err) => { console.error(phase + ":", err); return false; },
};
async function autoload(address, config) {
    return await _autoload(address, config, new Set());
}
async function _autoload(address, config, visitedAddresses) {
    if (config === undefined) {
        throw new errors.AutoloadError("config is undefined, must include 'provider'");
    }
    const onProgress = config.onProgress || exports.defaultConfig.onProgress;
    const onError = config.onError || exports.defaultConfig.onError;
    const provider = (0, providers_js_1.CompatibleProvider)(config.provider);
    const result = {
        address,
        abi: [],
        proxies: [],
        hasCode: false,
    };
    let abiLoader = config.abiLoader;
    if (abiLoader === undefined)
        abiLoader = loaders_js_1.defaultABILoader;
    if (!isAddress(address)) {
        onProgress("resolveName", { address });
        if (config.addressResolver) {
            address = await config.addressResolver(address);
        }
        else {
            try {
                address = await provider.getAddress(address);
            }
            catch (err) {
                throw new errors.AutoloadError(`Failed to resolve ENS address using provider.getAddress, try supplying your own resolver in AutoloadConfig by specifying addressResolver`, {
                    context: { address },
                    cause: err,
                });
            }
        }
    }
    const proxyPath = new Set(visitedAddresses);
    proxyPath.add(address.toLowerCase());
    onProgress("getCode", { address });
    let bytecode;
    try {
        bytecode = await provider.getCode(address);
    }
    catch (err) {
        throw new errors.AutoloadError(`Failed to fetch contract code due to provider error: ${err instanceof Error ? err.message : String(err)}`, {
            context: { address },
            cause: err,
        });
    }
    if (!bytecode || bytecode === "0x")
        return result;
    result.hasCode = true;
    const program = (0, disasm_js_1.disasm)(bytecode);
    result.proxies = program.proxies;
    result.isFactory = program.isFactory;
    const facets = {
        [address]: [],
    };
    if (result.proxies.length === 1 && result.proxies[0] instanceof proxies_js_1.DiamondProxyResolver) {
        onProgress("loadDiamondFacets", { address });
        const diamondProxy = result.proxies[0];
        const f = await diamondProxy.facets(provider, address);
        Object.assign(facets, f);
    }
    else if (result.proxies.length > 0 && program.sstoreCount <= PROXY_SSTORE_COUNT_MAX) {
        result.followProxies = async function (selector) {
            for (const resolver of result.proxies) {
                onProgress("followProxies", { resolver: resolver, address });
                const resolved = await resolver.resolve(provider, address, selector);
                if (resolved !== undefined && resolved !== ZERO_ADDRESS) {
                    if (proxyPath.has(resolved.toLowerCase())) {
                        onError("followProxies", new errors.AutoloadError(`Proxy cycle detected while resolving ${address}`, {
                            context: { address, resolved },
                        }));
                        return result;
                    }
                    return await _autoload(resolved, config, proxyPath);
                }
            }
            onError("followProxies", new Error("failed to resolve proxy"));
            return result;
        };
        if (config.followProxies) {
            return await result.followProxies();
        }
    }
    if (abiLoader) {
        onProgress("abiLoader", { address, facets: Object.keys(facets) });
        const loader = abiLoader;
        let abiLoadedFrom = loader;
        let originalOnLoad;
        if (loader instanceof loaders_js_2.MultiABILoader) {
            const onLoad = (loader) => {
                abiLoadedFrom = loader;
            };
            originalOnLoad = loader.onLoad;
            if (!loader.onLoad)
                loader.onLoad = onLoad;
            else {
                const original = loader.onLoad;
                loader.onLoad = (loader) => { original(loader); onLoad(loader); };
            }
        }
        try {
            if (config.loadContractResult) {
                const contractResult = await loader.getContract(address);
                if (contractResult && Array.isArray(contractResult.abi) && contractResult.abi.length > 0) {
                    result.contractResult = contractResult;
                    result.abi = contractResult.abi;
                    result.abiLoadedFrom = contractResult.loader;
                    return result;
                }
            }
            else {
                const addresses = Object.keys(facets);
                const promises = addresses.map(addr => loader.loadABI(addr));
                const results = await Promise.all(promises);
                const abis = Object.fromEntries(results.map((abi, i) => {
                    return [addresses[i], abi];
                }));
                result.abi = pruneFacets(facets, abis);
                if (result.abi.length > 0) {
                    result.abiLoadedFrom = abiLoadedFrom;
                    return result;
                }
            }
        }
        catch (error) {
            if (onError("abiLoader", error) === true)
                return result;
        }
        finally {
            if (loader instanceof loaders_js_2.MultiABILoader) {
                loader.onLoad = originalOnLoad;
            }
        }
    }
    onProgress("abiFromBytecode", { address });
    result.abi = (0, disasm_js_1.abiFromBytecode)(program);
    if (!config.enableExperimentalMetadata) {
        result.abi = stripUnreliableABI(result.abi);
    }
    result.abi.push(...Object.values(facets).flat().map(selector => {
        return {
            type: "function",
            selector,
        };
    }));
    let signatureLookup = config.signatureLookup;
    if (signatureLookup === undefined)
        signatureLookup = loaders_js_1.defaultSignatureLookup;
    if (!signatureLookup)
        return result;
    onProgress("signatureLookup", { abiItems: result.abi.length });
    let promises = [];
    for (const a of result.abi) {
        if (a.type === "function") {
            promises.push(signatureLookup.loadFunctions(a.selector).then((r) => {
                if (r.length >= 1) {
                    a.sig = r[0];
                    const extracted = AbiFunction.from("function " + a.sig, { prepare: false });
                    if (extracted.outputs.length === 0) {
                        delete (extracted.outputs);
                    }
                    Object.assign(a, extracted);
                }
                if (r.length > 1)
                    a.sigAlts = r.slice(1);
            }));
        }
        else if (a.type === "event") {
            promises.push(signatureLookup.loadEvents(a.hash).then((r) => {
                if (r.length >= 1) {
                    a.sig = r[0];
                    Object.assign(a, AbiEvent.from("event " + a.sig, { prepare: false }));
                }
                if (r.length > 1)
                    a.sigAlts = r.slice(1);
            }));
        }
    }
    const promiseResults = await Promise.allSettled(promises);
    const rejectedPromises = promiseResults.filter((r) => r.status === "rejected");
    if (rejectedPromises.length > 0) {
        const cause = rejectedPromises.length === 1
            ? rejectedPromises[0].reason
            : new AggregateError(rejectedPromises.map((r) => r.reason));
        throw new errors.AutoloadError(`Failed to fetch signatures due to loader error: ${cause.message}`, {
            context: { address },
            cause,
        });
    }
    return result;
}
function stripUnreliableABI(abi) {
    const r = [];
    for (const a of abi) {
        if (a.type !== "function")
            continue;
        r.push({
            type: "function",
            selector: a.selector,
        });
    }
    return r;
}
function pruneFacets(facets, abis) {
    const r = [];
    for (const [addr, abi] of Object.entries(abis)) {
        const allowSelectors = new Set(facets[addr]);
        if (allowSelectors.size === 0) {
            r.push(...abi);
            continue;
        }
        for (let a of abi) {
            if (a.type !== "function") {
                r.push(a);
                continue;
            }
            a = a;
            let selector = a.selector;
            if (selector === undefined && a.name) {
                selector = AbiFunction.getSelector(a);
            }
            if (allowSelectors.has(selector)) {
                r.push(a);
            }
        }
    }
    return r;
}
//# sourceMappingURL=auto.js.map